DROP TABLE IF EXISTS books;

DROP TABLE IF EXISTS authors;
CREATE TABLE authors (
  name_of VARCHAR(50) Not NULL,
  code VARCHAR(3) NOT NULL,
  pic VARCHAR(100) NULL,
  website VARCHAR(100) NULL,
  y_born INT(4) NULL,
  y_died INT(4) NULL,
  m_f_u VARCHAR(6) NULL,
  PRIMARY KEY(name_of))
  TYPE = INNODB;
  
INSERT INTO authors VALUES ("Kristin Cashore","CAS","kcash.jpg","http://kristincashore.blogspot.com",1976,NULL,"female");
INSERT INTO authors VALUES ("Naomi Novik","NOV","something","something else",1901,NULL,"female");
INSERT INTO authors VALUES ("Gerald Graff","GRA","something","something else",1901,NULL,"male");
INSERT INTO authors VALUES ("Cathy Birkenstein","BIR","something","something else",1901,NULL,"female");
INSERT INTO authors VALUES ("Shelley Moore Thomas","THO","something","something else",1901,NULL,"female");
INSERT INTO authors VALUES ("Holly Black","BLA","something","something else",1901,NULL,"female");
INSERT INTO authors VALUES ("Cassandra Clare","CLA","something","something else",1901,NULL,"female");
INSERT INTO authors VALUES ("Justin Sayre","SAY","something","something else",1901,NULL,"male");
INSERT INTO authors VALUES ("Heidi Schulz","SCH","something","something else",1901,NULL,"female");
INSERT INTO authors VALUES ("Donna Hosie","HOS","something","something else",1901,NULL,"female");
INSERT INTO authors VALUES ("A.C. Gaughen","GAU","something","something else",1901,NULL,"female");
INSERT INTO authors VALUES ("Stephanie Oakes","OAK","a pic","a link",1900,NULL,"female");

DROP TABLE IF EXISTS publishers;
CREATE TABLE publishers (
  company VARCHAR(20) NOT NULL,
  location VARCHAR(25) NOT NULL,
  internship VARCHAR(3) NOT NULL,
  PRIMARY KEY(company))
  TYPE = INNODB;
  
INSERT INTO publishers VALUES ("Penguin","New York","Yes");
INSERT INTO publishers VALUES ("Holiday House","New York","No");
INSERT INTO publishers VALUES ("Hyperion","New York","Yes");
INSERT INTO publishers VALUES ("Gosset & Dunlap","New York","Yes");
INSERT INTO publishers VALUES ("Farrar Straus Giroux","New York","No");
INSERT INTO publishers VALUES ("Scholastic Press","New York","Yes");
INSERT INTO publishers VALUES ("W.W. Norton","New York","Yes");
INSERT INTO publishers VALUES ("Del Ray","New York","Yes");
INSERT INTO publishers VALUES ("Simon & Schuster","New York","Yes");
INSERT INTO publishers VALUES ("Crown Publishing","New York","Yes");
INSERT INTO publishers VALUES ("Tin House","New York","Yes");
INSERT INTO publishers VALUES ("Dial Books","New York","No");
INSERT INTO publishers VALUES ("Bloomsbury","London","Yes");

DROP TABLE IF EXISTS editors;
CREATE TABLE editors (
  fl_name VARCHAR(30) NOT NULL,
  company VARCHAR(20) NOT NULL,
  contact VARCHAR(50) NOT NULL,
  PRIMARY KEY(fl_name))
  TYPE = INNODB;
  
INSERT INTO editors VALUES ("Some Lady","Penguin","somelady@gmail.com");
INSERT INTO editors VALUES ("Some Other Lady","Simon & Schuster","someolady@gmail.com");
INSERT INTO editors VALUES ("Anne Groell","Del Ray","anne@gmail.com");
INSERT INTO editors VALUES ("Francesco Sedita","Grosset & Dunlap","grosset@gmail.com");
INSERT INTO editors VALUES ("Whoever","Crown","who@gmail.com");
INSERT INTO editors VALUES ("A Lovely Person","Tin House","alove@gmail.com");
INSERT INTO editors VALUES ("Pumpkin Pie","Penguin Random House","pumpkin@gmail.com");
INSERT INTO editors VALUES ("So Much","Crown","crown@gmail.com");
INSERT INTO editors VALUES ("Why God","Grey Wolf","wolf@gmail.com");
INSERT INTO editors VALUES ("Almost Done","Scholastic Press","schol@gmail.com");
INSERT INTO editors VALUES ("Kelly Loughman","Knopf","knockoff@gmail.com");


CREATE TABLE books (
  ID int NOT NULL AUTO_INCREMENT,
  title VARCHAR(50) NOT NULL,
  author VARCHAR(50) NULL,
  publisher VARCHAR(50) NULL,
  color VARCHAR(10) NULL,
  year_pub INT(4) NULL,
  read_y_n VARCHAR(3) NULL,
  genre VARCHAR(20) NULL,
  editor VARCHAR(40) NULL,
  type_of VARCHAR(20) NULL,
  PRIMARY KEY(ID),
  FOREIGN KEY(author) REFERENCES authors(name_of),
  FOREIGN KEY(publisher) REFERENCES publishers(company),
  FOREIGN KEY(editor) REFERENCES editors(fl_name))
  TYPE = INNODB;
  
INSERT INTO books VALUES (NULL,"Graceling","Kristin Cashore","Penguin","green",2012,"yes","fantasy","Some Lady","signed");
INSERT INTO books VALUES (NULL,"Husky","Justin Sayre","Gosset & Dunlap","yellow",2015,"no","realism","Francesco Sedita","ARC");
INSERT INTO books VALUES (NULL,"Uprooted","Naomi Novik","Del Ray","yellow",2015,"yes","fantasy","Anne Groell","other");
INSERT INTO books VALUES (NULL,"Secrets of Selkie Bay","Shelley Moore Thomas","Farrar Straus Giroux","purple",2015,"no","mystery","Some Lady","ARC");
INSERT INTO books VALUES (NULL,"The Iron Trial","Holly Black","Scholastic Press","blue",2014,"no","middlegrade","Some Other Lady","ARC");
INSERT INTO books VALUES (NULL,"They Say, I Say","Gerald Graff","W.W. Norton","blue",2014,"no","academic","Whoever","textbook");
INSERT INTO books VALUES (NULL,"Hook's Revenge: The Pirate Code","Heidi Schulz","Hyperion","blue",2015,"no","middlegrade","A Lovely Person","ARC");
INSERT INTO books VALUES (NULL,"The Devil's Intern","Donna Hosie","Holiday House","red",2014,"no","fantasy","Kelly Loughman","other");
INSERT INTO books VALUES (NULL,"The Sacred Lies of Minnow Bly","Stephanie Oakes","Dial Books","black",2015,"no","historical fiction","So Much","ARC");
INSERT INTO books VALUES (NULL,"Lion Heart","A.C. Gaughen","Bloomsbury","black",2015,"no","historical fiction","Why God","ARC");
