<?php

ini_set('display_errors', true);
ini_set('display_startup_errors', true);
error_reporting(E_ALL);

$db_type           = "mysql";
$db_server         = "warehouse.cims.nyu.edu";
$db_name           = "jeb649_A7";
$db_user           = "jeb649";
$db_password       = "trash";
?>