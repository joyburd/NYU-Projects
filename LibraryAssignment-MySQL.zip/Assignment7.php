<!DOCTYPE html>
<html>
 <head>
   <title>Assignment 7</title>
   <link href="Assingment7.css" rel="stylesheet" type="text/css" />
 </head>
 <body>
   <h3>Books!!!</h3>
   <hr />
   
   
<?php
   
   
      //1. obtain the HTML variables 
      $info = $_GET['info'];
      $author = $_GET['name'];
      
      // 2. obtain the PHP credentials for the database
	  include("/home/jeb649/A7.php");      
      
      // 3. open the database
      $db_link =new mysqli($db_server,$db_user,$db_password,$db_name);
      
      // 4. create the query (string)
      
      /*in my foolhardy youth and inexperience, i decided i was going to link up
      all these tables and give the user options on stuff and this is what i had to do
      each loop inner joins a different table to give different info
      I'm not gonna label comment them because I feel like the table names provided are pretty
      self-explanatory*/
      
      if ($info=='books')
      	$query = "SELECT name_of, title, publisher, genre, pic, website
      	FROM books b
      	INNER JOIN authors a ON a.name_of = b.author
      	WHERE a.name_of = \"$author\"";
      	
      elseif ($info=='publishers')
      	$query = "SELECT name_of, company, location, website
      	FROM publishers p
      	INNER JOIN books b ON b.publisher=p.company
      	INNER JOIN authors a ON a.name_of=b.author
      	WHERE a.name_of = \"$author\"";
      	
      elseif ($info=='editors')
      	$query = "SELECT name_of, fl_name, company, contact
      	FROM editors e
      	INNER JOIN books b ON b.editor=e.fl_name
      	INNER JOIN authors a ON b. author=a.name_of
      	WHERE a.name_of = \"$author\"";
      	
       print("\n<p>Query: ".$query."</p>\n");
      
      // 5. execute the query
      $result = mysqli_query($db_link,$query);  
      
      // 6. get the results (check for number of records > 0)
      $num_rows = mysqli_num_rows($result);      
      
      // 7. display the results
	  if ($num_rows == 0) {
	  	print("\n<p>Sorry, nothing here.</p>\n");}
	  else {
	  	while ($line = mysqli_fetch_array($result,MYSQL_ASSOC)) {
	  	print("<table>\n
	  		<tr>\n");
	  	foreach ($line as $col_value) {
	  			if (substr($col_value, -3) == 'jpg')
	  				print("\t<td><img src=\"$col_value\" alt='authorphoto' height='75'></td>\n");
	  			elseif (substr($col_value, 0, 4) == 'http')
	  				print("\t\t<td><a href=\"$col_value\">$col_value</a></td>\n");
	  			else
	  				print("\t\t<td>$col_value</td>\n");
	  		} /*end foreach*/
	  		print('</tr>');
	  	} /*end while*/
	  	print("</table>\n");
	 } 		/*end else*/
      
      // 8. closin' stuff
         mysqli_free_result($result);
         mysqli_close($db_link);
   ?>
 </body>
</html>