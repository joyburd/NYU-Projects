<html>
<head>
<title>Library</title>
<link href="Assingment7.css" rel="stylesheet" type="text/css"/>
</head>
<body>
<h3>
Welcome to My Lil' Library</h3>
<h5> Ready to see the most pathetic library database of your goddamn life? </h5>


<h5> I thought you would be </h5>

<h6> I would now like to present you with the soul-gripping opportunity to pick an author: </h6>

<form action="Assignment7.php"  method='GET'>

<?php

/* author choice drop down with loaded vocab
because my database is presently so small, i chose to do a drop down
i would expand this upon fully recognizign the project into an entry search format
as it stands drop downs just make me more comfortable :) 
plus at this point the assignment asks for them so here they are*/
print( "<p>Author:<br />\n");
include ('/home/jeb649/A7.php');

/*connecting*/
$db_link = new mysqli($db_server, $db_user, $db_password, $db_name);
if ($db_link->connect_errno) {
print( "Failed to connect to MySQL: (" .$db_link->connect_errno . ") ".$db_link->connect_error);
}

/*the query*/
$query =
"SELECT name_of 
 FROM authors
 ORDER BY name_of; ";
$result = mysqli_query($db_link,$query);

/*result with formatting for a form*/
print( "<select name=name>");
while ($line = mysqli_fetch_array($result, MYSQL_NUM)) { 
    print("<option value=\"$line[0]\">$line[0]</option>\n");
      }
print("</select>\n</p>\n");

/*include
of note: in reality, authors have multiple books, and often work with multiple editors and publishers
my data won't reflect that presently as I don't have dual entries
but theoretically, it would
right now this is just acting as a very small set of fun tidbits*/
print("<h6> What would you like with that?</h6>\n\n");
print('<input type="radio" name="info" value="books" checked>Book Info
     <input type="radio" name="info" value ="publishers">Publisher Info
     <input type="radio" name="info" value ="editors">Editor Info
	 </p>');

print("<p>
     <input type=submit value=Submit>
     <input type=reset value=Cancel>
     </p>" );

/* Free resultset */
  mysqli_free_result($result);

 /* Closing connection */
mysqli_close($db_link);
 ?>

</form>
</body>
</html>